import { Misfit } from "../types";

export const MISFITS: Misfit[] = [
  {
    id: "ray",
    name: "Ray",
    class: "Chaos Engine",
    description: "Placeholder description.",

    hp: 85,
    speed: 70,
    range: 90,

    attack: "4 pure energy blasts",
    ultimate: "Chaos Overload",

    image: "/misfitz/ray.png",

    accentColor: "#ff4545",
  },

  {
    id: "rush",
    name: "Rush",
    class: "Placeholder Class",
    description: "Placeholder description.",

    hp: 75,
    speed: 95,
    range: 55,

    attack: "Placeholder attack",
    ultimate: "Placeholder ultimate",

    image: "/misfitz/rush.png",

    accentColor: "#f59e0b",
  },

  {
    id: "beat",
    name: "Beat",
    class: "Placeholder Class",
    description: "Placeholder description.",

    hp: 95,
    speed: 45,
    range: 65,

    attack: "Placeholder attack",
    ultimate: "Placeholder ultimate",

    image: "/misfitz/beat.png",

    accentColor: "#3b82f6",
  },

  {
    id: "gloss",
    name: "Gloss",
    class: "Placeholder Class",
    description: "Placeholder description.",

    hp: 65,
    speed: 80,
    range: 75,

    attack: "Placeholder attack",
    ultimate: "Placeholder ultimate",

    image: "/misfitz/gloss.png",

    accentColor: "#ec4899",
  },

  {
    id: "shade",
    name: "Shade",
    class: "Placeholder Class",
    description: "Placeholder description.",

    hp: 60,
    speed: 90,
    range: 70,

    attack: "Placeholder attack",
    ultimate: "Placeholder ultimate",

    image: "/misfitz/shade.png",

    accentColor: "#a855f7",
  },

  {
    id: "drip",
    name: "Drip",
    class: "Placeholder Class",
    description: "Placeholder description.",

    hp: 80,
    speed: 60,
    range: 85,

    attack: "Placeholder attack",
    ultimate: "Placeholder ultimate",

    image: "/misfitz/drip.png",

    accentColor: "#22c55e",
  },
];